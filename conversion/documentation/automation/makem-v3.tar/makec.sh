#!/bin/bash

cat control_list.txt | while read line
do
   #var declaration
   UTIL=`echo $line | cut -f1 -d"|"`;
   MAINTAINER=`echo $line | cut -f2 -d"|"`;
   VERSION=`echo $line | cut -f3 -d"|"`;
   DESCRIPTION=`echo $line | cut -f4 -d"|"`;

   STATEMENT="sed -e 's/<<TOOL>>/"${UTIL}"/g' ./owasp-control.txt >  $UTIL/DEBIAN/control.tmp1"
   eval $STATEMENT
   STATEMENT="sed -e 's/<<MAINTAINER>>/"${MAINTAINER}"/g' ${UTIL}/DEBIAN/control.tmp1  >  ${UTIL}/DEBIAN/control.tmp2"
   eval $STATEMENT
   STATEMENT="sed -e 's/<<VERSION>>/"${VERSION}"/g' ${UTIL}/DEBIAN/control.tmp2 > ${UTIL}/DEBIAN/control.tmp3"
   eval $STATEMENT
   STATEMENT="sed -e 's/<<DESCR>>/"${DESCRIPTION}"/g' ${UTIL}/DEBIAN/control.tmp3 > ${UTIL}/DEBIAN/control.tmp4"
   eval $STATEMENT
   STATEMENT="mv $UTIL/DEBIAN/control.tmp4 $UTIL/DEBIAN/control"
   eval $STATEMENT
   STATEMENT="rm "$UTIL"/DEBIAN/control.tmp*"
   eval $STATEMENT
   
done
