sudo rm /usr/share/applications/owasp-*
sudo rm /usr/share/desktop-directories/owasp-*
sudo rm /etc/xdg/menus/applications-merged/owasp-*
