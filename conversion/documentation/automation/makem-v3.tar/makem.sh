#!/bin/bash

cat list.txt | while read line
do
   #var declaration
   UTIL=`echo $line | cut -f1 -d"|"`;
   UTILNAME=`echo $line | cut -f2 -d"|"`;
   CATEGORY=`echo $line | cut -f3 -d"|"`;
   MENUFILE=`echo $line | cut -f4 -d"|"`;
   EXECLINE=`echo $line | cut -f5 -d"|"`;

   #make the dirs we need
   mkdir $UTIL
   mkdir $UTIL/tmp
   mkdir $UTIL/tmp/owasp-wte-$UTIL
   mkdir $UTIL/DEBIAN
  
   #copy the files we need
   cp icon/owasp-wte-$UTIL-icon.png $UTIL/tmp/owasp-wte-$UTIL
   cp icon/owasp-wte-menu-icon.png $UTIL/tmp/owasp-wte-$UTIL
   cp directory/owasp-owasp.directory $UTIL/tmp/owasp-wte-$UTIL
   cp directory/$MENUFILE.directory $UTIL/tmp/owasp-wte-$UTIL

   #determine which postinst is needed
   if [ "${MENUFILE}" == "" ] 
   then
      POSTINST="./postinst1"
   else
      POSTINST="./postinst2" 
      cp menu/${MENUFILE}.menu $UTIL/tmp/owasp-wte-$UTIL
      cp menu/owasp-owasp.menu $UTIL/tmp/owasp-wte-$UTIL
   fi

   STATEMENT="sed -e 's/<<TOOL>>/"${UTIL}"/g' ./owasp-app.desktop >  $UTIL/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop.tmp"
   eval $STATEMENT
   STATEMENT="sed -e 's/<<CATEGORY>>/"${CATEGORY}"/g' $UTIL/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop.tmp  >  ${UTIL}/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop.tmp2"
   eval $STATEMENT
   STATEMENT="sed -e 's/<<UTILNAME>>/"${UTILNAME}"/g' $UTIL/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop.tmp2 > ${UTIL}/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop.tmp3"
   eval $STATEMENT
   STATEMENT="sed -e 's/<<EXEC>>/"${EXECLINE}"/g' $UTIL/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop.tmp3 > ${UTIL}/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop.tmp4"
   eval $STATEMENT
   STATEMENT="mv $UTIL/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop.tmp4 $UTIL/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop"
   eval $STATEMENT
   STATEMENT="rm $UTIL/tmp/owasp-wte-$UTIL/owasp-wte-${UTIL}.desktop.tmp*"
   eval $STATEMENT
   
   
   STATEMENT="sed -e 's/<<TOOL>>/"${UTIL}"/g' "${POSTINST}" > "${UTIL}"/DEBIAN/postinst.tmp1"
   eval $STATEMENT
   STATEMENT="sed -e 's/<<MENUFILE>>/"${MENUFILE}"/g' "${UTIL}"/DEBIAN/postinst.tmp1 > "${UTIL}"/DEBIAN/postinst.tmp2"
   eval $STATEMENT
   STATEMENT="mv "${UTIL}"/DEBIAN/postinst.tmp2 "${UTIL}"/DEBIAN/postinst"
   eval $STATEMENT
   STATEMENT="rm "${UTIL}"/DEBIAN/postinst.tmp*"
   eval $STATEMENT
   STATEMENT="chmod 755 "${UTIL}"/DEBIAN/postinst"
   eval $STATEMENT

done
