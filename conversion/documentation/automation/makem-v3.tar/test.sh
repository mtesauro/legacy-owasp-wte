#!/bin/bash

cat list.txt | while read line
do

  UTIL=`echo $line | cut -f1 -d"|"`;

  cp $UTIL/tmp/* /tmp
  $UTIL/DEBIAN/postinst

done
